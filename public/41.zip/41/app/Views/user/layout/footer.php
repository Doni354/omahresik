<!-- Footer Start -->

<div class="container-fluid copyright py-4">
    <div class="container">
        <div class="footer-border">

            <div class="row">
                <div class="col-xl-12 ">
                    <div class="footer-copy-right text-center">
                        <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                            Copyright &copy;<script>
                                document.write(new Date().getFullYear());
                            </script>. <?php foreach ($profil as $footer) : ?><?= $footer->teks_footer; ?><?php endforeach; ?></a> <!-- License information: https://untree.co/license/ -->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer End -->