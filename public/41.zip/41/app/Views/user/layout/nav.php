<!-- Navbar Start -->
<div class="container-fluid bg-white sticky-top">
        <?php foreach ($profil as $header) :  ?>

            <div class="container">
                <nav class="navbar navbar-expand-lg bg-white navbar-light py-2 py-lg-0">
                    <a href="<?= base_url('user/home') ?>" class="navbar-brand">
                        <img class="img-fluid" src="<?= base_url('asset-user/images/'); ?><?= $header->logo_perusahaan ?>" alt="Logo">
                    </a>
                    <button type="button" class="navbar-toggler ms-auto me-0" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarCollapse">
                        <div class="navbar-nav ms-auto">
                            <a id="home-link" href="<?= base_url('/') ?>" class="nav-item nav-link <?php if (current_url() == base_url('/') || current_url() == base_url()) echo 'active'; ?>"><?php echo lang('Blog.headerHome'); ?></a>
                            <a href="<?= base_url('about') ?>" class="nav-item nav-link"><?php echo lang('Blog.headerAbout'); ?></a>
                            <a href="<?= base_url('product') ?>" class="nav-item nav-link"><?php echo lang('Blog.headerProducts'); ?></a>
                            <a href="<?= base_url('activities') ?>" class="nav-item nav-link"><?php echo lang('Blog.headerActivities'); ?></a>
                            <a href="<?= base_url('contact') ?>" class="nav-item nav-link"><?php echo lang('Blog.headerContact'); ?></a>
                            <div class="nav-item dropdown">
                                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Languange</a>
                                <div class="dropdown-menu bg-light rounded-0 m-0">
                                    <a href="<?= site_url('lang/in') ?>" class="dropdown-item">Indonesia</a>
                                    <a href="<?= site_url('lang/en') ?>" class="dropdown-item">English</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </nav>
                <br>
            </div>
        <?php endforeach;  ?>
    </div>

    <!-- Navbar End -->