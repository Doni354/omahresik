<?= $this->extend('user/template/template') ?>
<?= $this->Section('content'); ?>
<!-- TEST SLIDER img -->
<?= $this->include('user/home/slider'); ?>

<br>
<br>
<div class="container-fluid mt-5 mb-5 py-5 py-lg-0 feature">
    <?php foreach ($profil as $title) : ?>
        <h1 class="section-title mb-4 text-center"><?= $title->title_website; ?></h1>
    <?php endforeach; ?>
</div>
<!-- Features End -->
<br>
<br>
<!-- About Start -->
<div class="container-xxl py-5">
    <div class="container">
        <?php foreach ($profil as $descper) : ?>

            <div class="row g-5">
                <div class="col-lg-6">
                    <div class="row g-3">
                        <div class="col-xl-7 col-lg-7">
                            <div class="trusted-img">
                                <img data-src="asset-user/images/<?= $descper->foto_utama; ?>" <?php foreach ($profil as $perusahaan) :  ?>alt="<?= $perusahaan->nama_perusahaan; ?>" <?php endforeach; ?> class="img-fluid img-overlap lazyload">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
                    <div class="section-title">
                        <p class="fs-5 fw-medium fst-italic text-primary"><?php echo lang('Blog.titleAboutUs')  ?></p>
                        <h1 class="display-6"><?= $descper->nama_perusahaan; ?></h1>
                    </div>
                    <div class="border-top mb-4"></div>
                    <div class="row g-3">
                        <p class="mb-0"><?php if (lang('Blog.Languange') == 'en') {
                                            echo character_limiter($descper->deskripsi_perusahaan_en, 700);
                                        } ?>
                            <?php if (lang('Blog.Languange') == 'in') {
                                echo character_limiter($descper->deskripsi_perusahaan_in, 700);
                            } ?></p>
                        <a href="about" class="btn-left trusted-btn"><?php echo lang('Blog.btnReadmore'); ?></a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
<!-- About End -->

<!-- Products Start -->
<div class="container-fluid product py-5 my-5">
    <div class="container py-5">
        <div class="row">
            <div class="section-title text-center mx-auto wow fadeInUp" data-wow-delay="0.1s" style="max-width: 500px;">
                <h1 class="display-6 text-primary"><?php echo lang('Blog.btnOurproducts'); ?></h1>
            </div>
        </div>
    </div>

    <div class="container" style="overflow-x: auto;"> <!-- Added container to restrict width and enable scrolling -->
        <div class="row">
            <?php $count = 0;
            foreach ($tbproduk as $produk) :
                if ($count < 3) { ?>
                    <div class="col-xl-4 col-lg-4 col-md-6">
                        <div class="single-recent-cap mb-30">
                            <div class="recent-img" style="max-width: 100%;">
                                <img src="asset-user/images/<?= $produk->foto_produk; ?>" alt="<?php if (lang('Blog.Languange') == 'en') {
                                    echo $produk->nama_produk_en;
                                } ?>
                                        <?php if (lang('Blog.Languange') == 'in') {
                                            echo $produk->nama_produk_in;
                                        } ?>" style="width: 100%;"> <!-- Set a fixed width for the images -->
                            </div>
                            <div class="recent-cap">
                                <a href="<?= base_url('product/detail/' . $produk->id_produk . '/' . url_title($produk->nama_produk_en) . '_' . url_title($produk->nama_produk_in)) ?>">
                                    <h4>
                                        <?php if (lang('Blog.Languange') == 'en') {
                                            echo $produk->nama_produk_en;
                                        } ?>
                                        <?php if (lang('Blog.Languange') == 'in') {
                                            echo $produk->nama_produk_in;
                                        } ?>
                                    </h4>
                                </a>
                            </div>
                        </div>
                    </div>
            <?php
                    $count++;
                }
            endforeach; ?>
        </div>
    </div>

    <br>
    <br>
    <div class="d-flex justify-content-center"> <!-- Centering the button -->
        <a href="<?= base_url('product') ?>" class="btn btn-lg px-4 btn-primary"><?php echo lang('Blog.btnOurproducts'); ?></a>
    </div>
</div>
<!-- Products End -->



<?= $this->endSection('content') ?>