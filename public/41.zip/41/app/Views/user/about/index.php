<?= $this->extend('user/template/template') ?>
<?= $this->Section('content'); ?>

<div class="container-fluid page-header-2 py-5 mb-5 wow fadeIn lazyload" data-wow-delay="0.1s" style="min-height: 500px; display: flex; align-items: center; justify-content: center;">
    <div class="container text-center py-5">
        <?php foreach ($profil as $perusahaan) : ?>
            <h1 class="text-white">
                <?php echo lang('Blog.titleAboutUs');
                if (!empty($perusahaan)) {
                    echo ' ' . $perusahaan->nama_perusahaan;
                } ?>
            </h1>
        <?php endforeach; ?>
        <div class="d-inline-flex text-white m-3 p-3" style="border-radius: 8px;">
            <p class="m-0 text-uppercase"><a class="text-white" href="<?= base_url('/') ?>"><?php echo lang('Blog.Blog.headerHome'); ?></a></p>
            <i class="fa fa-angle-double-right pt-1 px-3"></i>
            <span><?php echo lang('Blog.headerAbout');  ?></span>
        </div>
    </div>
</div>
<!-- About Start -->
<div class="container-xxl py-5">
    <div class="container">
        <?php foreach ($profil as $descper) : ?>

            <div class="row g-5">
                <div class="col-lg-6">
                    <div class="row g-3">
                        <div class="col-xl-7 col-lg-7">
                            <div class="trusted-img">
                                <img data-src="asset-user/images/<?= $descper->foto_utama; ?>" <?php foreach ($profil as $perusahaan) :  ?>alt="<?= $perusahaan->nama_perusahaan; ?>" <?php endforeach; ?> class="img-fluid img-overlap lazyload">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
                    <div class="section-title">
                        <p class="fs-5 fw-medium fst-italic text-primary"><?php echo lang('Blog.titleAboutUs')  ?></p>
                        <h1 class="display-6"><?= $descper->nama_perusahaan; ?></h1>
                    </div>
                    <div class="border-top mb-4"></div>
                    <div class="row g-3">
                        <p class="mb-0"><?php if (lang('Blog.Languange') == 'en') {
                                            echo character_limiter($descper->deskripsi_perusahaan_en, 1000);
                                        } ?>
                            <?php if (lang('Blog.Languange') == 'in') {
                                echo character_limiter($descper->deskripsi_perusahaan_in, 1000);
                            } ?></p>
                        <!--<a href="about" class="btn-left trusted-btn"><?php echo lang('Blog.btnReadmore'); ?></a>-->
                    </div>
                </div>
            </div>
        <?php endforeach; ?>

    </div>
</div>
<!-- About End -->
<?= $this->endSection('content'); ?>