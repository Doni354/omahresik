<?php

return [
    'notelp' => 'Telfon kami',
    'email' => 'Email kami',
    'headerHome' => 'Beranda',
    'headerAbout' => 'Tentang',
    'headerProducts' => 'Produk',
    'headerActivities' => 'Aktivitas',
    'headerContact' => 'Kontak',
    'btnReadmore' => 'Baca Selengkapnya',
    'btnOurproducts' => 'Produk Kami',
    'titleOurproducts' => 'Produk dari',
    'titleActivities' => 'Aktivitas dari',
    'titleOurContact' => 'Kontak dari',
    'titleAboutUs' => 'Tentang Kami',
    'titleDescProd' => 'Deskripsi Produk',
    'titleDescActv' => 'Deskripsi Aktivitas',
    'Languange' => 'in',
];
